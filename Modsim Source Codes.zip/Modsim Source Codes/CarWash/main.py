class Queue():
    def __init__(self):
        self.items = []

    def is_empty(self):
        return self.items == []

    def equeue(self,item):
        self.items.insert(0,item)

    def dqueue(self):
        return self.items.pop()

    def size(self):
        return len(self.items)


class Carwash():

    def __init__(self, carMin):
        self.cpm = carMin
        self.current_car = None
        self.time_remaining = 0

    def tick(self):
        if self.current_car != None:
            self.time_remaining = self.time_remaining - 1
            if self.time_remaining <= 0:
                self.current_car = None

    def busyness(self):
        if self.current_car != None:
            return True
        else:
            return False

    def start_next(self, new_car):
        self.current_car = new_car
        self. time_remaining = new_car.get_cars() * 60 / self.cpm

import random
class Car():

    def __init__(self, time):
        self.timestamp = time
        self.cars = random.randrange(1,3)

    def get_stmap(self):
        return self.timestamp

    def get_cars(self):
        return self.cars

    def wait_time(self, current_time):
        return current_time - self.timestamp


def main(num_seconds, carMin):
    CW = Carwash(carMin)
    Q = Queue()
    w_time = []

    for second in range(num_seconds):
        car= Car(second)
        Q.equeue(car)

        if new_car():
            cara = Car(second)
            Q.equeue(cara)

        if (not CW.busyness()) and (not Q.is_empty()):
            next_car = Q.dqueue()
            w_time.append(next_car.wait_time(second))
            CW.start_next(next_car)

        CW.tick()

    avg_wait = sum(w_time) / len(w_time)

    print ("Average wait %s secs %d cars remaining." % (int(avg_wait), Q.size()))

def new_car():
    n = random.randrange(1,30)
    if n==30:
        return True
    else:
        return False

for i in range(10):
    main(100,14)














